


import tools.StdIn;
import tools.StdOut;

public class main {
	public static void main(String[] args) {
		int i = StdIn.readInt();
		
		
		StdOut.println(i);
		
	}

}
